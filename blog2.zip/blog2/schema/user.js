const mongoose = require('mongoose');

//定义数据库存储格式（用户信息）
const userSchema = new mongoose.Schema({
    //用户名
    username:String,
    //用户密码
    password:String,
    //是否是管理员
    isadmin:{
        type:Boolean,
        default:false   //默认都不是管理员
    }
});

//暴露用户的模型
module.exports = mongoose.model('user',userSchema);