const mongoose = require('mongoose');

//定义数据库存储格式（分类信息）
const contentSchema = new mongoose.Schema({
    //内容的名字
    title:String,
    //内容的简介
    description:String,
    //内容的主体
    content:String,
    //内容的标题  关联字段
    category:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'category'
    },
    //文章作者 关联本博客的user集合
    author:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'user'
    },
    //文章的阅读量
    views:{
        type:Number,
        default: 0,
    },
    //文章的评论数
    comment:{
        type:Array,
        default:[]
    },
    //文章发表的时间
    time:{
        type:Date,
        default:new Date(),//默认时间
    }
});

//暴露用户的模型
module.exports = mongoose.model('contents',contentSchema);