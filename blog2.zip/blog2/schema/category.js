const mongoose = require('mongoose');

//定义数据库存储格式（分类信息）
const categorySchema = new mongoose.Schema({
    //分类的名字
    name:String
});

//暴露用户的模型
module.exports = mongoose.model('category',categorySchema);