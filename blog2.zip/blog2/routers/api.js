const express = require('express');
const User = require('../schema/user');//引入用户信息

//定义一个空对象
let responseDate = {};
//设置api的路由
const router = express.Router();
//接受注册、登录信息

//注册的后台处理
router.post('/register',(req,res)=>{
    let {username,password,repassword}=req.body;//解构赋值
    //判断用户名
    if (username === ''){
        responseDate.code=1;
        responseDate.message='用户名不能为空';
        res.send(responseDate);//返回前台信息
        return;
    }
    //判断密码
    if (password === ''){
        responseDate.code=2;
        responseDate.message='密码不能为空';
        res.send(responseDate);
        return;
    }
    //判断确认密码
    if (repassword!==password){
        responseDate.code=3;
        responseDate.message='俩次密码不一致';
        res.send(responseDate);
        return;
    }
    //判断用户名是否已经被注册（即在数据库中查找），如果已经注册了，那这个注册是失败的。
    User.findOne({username}).then((somebody)=>{//在数据库中查找此用户名
        if (somebody){//如果存在
            responseDate.code=4;
            responseDate.message='该用户已经被注册过了';
            res.send(responseDate);
            return;
        }
        //注册成功保存用户信息
        new User({
            username,
            password,
        }).save().then(()=>{//返回注册成功的信息
            responseDate.code=0;
            responseDate.message='注册成功';
            res.send(responseDate);
        })

    })

});


//登录的后台处理
router.post('/login',(req,res)=>{
    let {username,password} = req.body;
    //判断用户名
    if (username === ''){
        responseDate.code=1;
        responseDate.message='用户名不能为空';
        res.send(responseDate);//返回前台信息
        return;
    }
    //判断密码
    if (password === ''){
        responseDate.code=2;
        responseDate.message='密码不能为空';
        res.send(responseDate);
        return;
    }
    //从数据库中查找，看是否存在，密码是否正确
    User.findOne({
        username,
        password,
    }).then((somebody)=>{
        if (!somebody){//如果没有找到这个用户
            responseDate.code=3;
            responseDate.message='用户名或者密码输入错误';
            res.send(responseDate);
            return
        }
            responseDate.code=0;
            responseDate.message='登录成功';
            //用来做cookie的值
            responseDate.userInfo={
                id:somebody._id,    //用户的id  用于后面访问作者
                username:somebody.username, //用户的名字
                isadmin:somebody.isadmin,
            };
            //设置cookie,用于用户下一次登录
                res.cookie('userInfo',JSON.stringify(responseDate.userInfo),{
                maxAge:900000,
            });
            res.send(responseDate);
        })
});

//退出的后台处理
router.post('/loginOut',(req,res)=>{
    //清除cookie
    res.cookie('userInfo','');
    res.send('cookie已经清除')
});


module.exports = router;