const express = require('express');
const category = require('../schema/category');//引入分类信息，用来渲染
const content = require('../schema/content');//引入内容信息，用来渲染
const router = express.Router();
//定义一个空对象用来接收所有信息
let data = {};
//用来处理通用数据
router.use((req,res,next)=>{
    data.userInfo=req.userInfo;
    category.find().then((categorys)=>{
        // console.log(results);
        data.categorys = categorys;
        next();
    });
});
//主页路由
router.get('/',(req,res)=> {
    //往data对象里添加分页信息
    data.page = +req.query.page || 1;
    data.limit = 3;
    data.category = req.query.category;
    //定义一个空数组用来判断点击的是首页还是分类
    let where = {};
    if (req.query.category) {
        where.category = req.query.category;
    }
    //从数据库中获取分类
    content.find(where).count().then((count) => {
        data.count = count;
        data.pageMax = Math.ceil(data.count / data.limit);
        data.page = Math.min(data.pageMax, data.page);
        data.skip = (data.page - 1) * data.limit;
        return content.find(where).limit(data.limit).skip(data.skip).sort({_id: -1}).populate('category');
    }).then((contents) => {
        data.contents = contents;
        res.render('main/index', data);
    });
})
//     category.find().then((categorys)=>{
//         // console.log(results);
//         data.categorys = categorys;
//         return content.find(where).count()//如果是首页则where值为空，如果是分类，则where值为category的值
//     }).then((count)=> {
//         data.count = count;
//         data.pageMax = Math.ceil(data.count/data.limit);
//         data.page = Math.min(data.pageMax,data.page);
//         data.skip = (data.page-1)*data.limit;
//         return content.find(where).limit(data.limit).skip(data.skip).sort({_id:-1}).populate('category');
//     }).then((contents)=>{
//         data.contents = contents;
//         res.render('main/index',data);
//     })
// });


//阅读全文的后台处理
router.get('/view',(req,res)=>{
    //获取当前文章的id值
    let contentId = req.query.contentId;
    content.findById({_id:contentId}).populate(['author','category']).then((content)=>{
        //评论数加1
        content.views++;
        content.save().then((content)=>{
            data.content = content;
            res.render('main/view',data)
        })
    })
});
//接收前台返回的评论信息
router.post('/comment',(req,res)=>{
    // console.log(req.body);

    //判断是否登录
    if (!req.userInfo) {
        data.code=1;
        data.message = '您还没有登录，请先登录';
        res.send(data);
        return;
    }
    let {comment,contentId} = req.body;
    //发表评论的所有相关信息
    let commentData = {
        //评论内容
        comment,
        //评论时间
        time:new Date,
        //评论的作者
        author:req.userInfo.username
    };

    content.findById(contentId).then((content)=>{
        //把评论加载到文章的属性中
        content.comment.push(commentData);
        // console.log(result)
        //保存这篇文章
        content.save().then(()=>{
            //把数据发送给前台
            res.send(content.comment)
        })
    })
})
module.exports = router;//暴露出去
