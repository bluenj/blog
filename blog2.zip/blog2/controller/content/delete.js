const Content = require('../../schema/content');

//渲染删除页面
exports.showDelete = function (req,res) {
    //获取内容id值
    let id = req.query.id;
    //从数据库中查询指定id
    Content.findById(id).populate('category').then((result)=>{
        // console.log(result);
        res.render('admin/content/delete',{
            userInfo:req.userInfo,
            result,
        })
    })
};


//从数据库中查找是否存在该标题，如果存在直接删除
exports.delete = function (req,res) {
    //拿到文章id值
    // let id = req.query.id;
    //拿到title值
    let title = req.body.title;
    if (title === '') {      //删除标题不能为空
        res.render('admin/error', {
            userInfo: req.userInfo,
            optionMessage: {
                location: '内容首页',
                option: '内容删除',
                message: '删除标题不能为空',
            }
        });
        return;
    }
    //查找是否存在，如果存在则直接删除
    Content.deleteOne({
        title: title,
    }).then((results) => {
        // console.log(results);
        if (!results.deletedCount) {//不存在该标题
            res.render('admin/error', {
                userInfo: req.userInfo,
                optionMessage: {
                    location: '内容首页',
                    option: '内容删除',
                    message: '对不起，不存在该标题',
                }
            });
            return;
        }
        res.render('admin/success', {
            userInfo: req.userInfo,
            optionMessage: {
                location: '内容首页',
                option: '内容删除',
                message: '亲，已经成功删除',
                href:'返回内容首页',
            },
            url:'/admin/content',
        });

    })
};