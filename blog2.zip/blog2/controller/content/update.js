//引入content内容列表的信息
const Content = require('../../schema/content');
//渲染修改页面
exports.showUpdate = function (req,res) {
    //当前内容名字
    // let cate = req.query.category;
    let id = req.query.id;
    //从数据库中查询指定id
    Content.findById(id).populate('category').then((result)=>{
        // console.log(result);
        res.render('admin/content/update',{
            userInfo:req.userInfo,
            result,
        })
    })
};

//接受修改内容的数据
exports.update = function (req,res) {
    let id = req.query.id;
    // console.log(id)
    let {title,description,content}=req.body;//解构赋值
    //判断标题是否为空
    if (title === '') {
        res.render('admin/error', {
            userInfo: req.userInfo,
            optionMessage: {
                location: '内容首页',
                option: '内容修改',
                message: '修改标题不能为空',
            }
        });
        return;
    }
    //判断简介是否为空
    if (description === '') {
        res.render('admin/error', {
            userInfo: req.userInfo,
            optionMessage: {
                location: '内容首页',
                option: '内容修改',
                message: '修改简介不能为空',
            }
        });
        return;
    }
    //判断内容是否为空
    if (content === '') {
        res.render('admin/error', {
            userInfo: req.userInfo,
            optionMessage: {
                location: '内容首页',
                option: '内容修改',
                message: '修改内容不能为空',
            }
        });
        return;
    }

    //更改内容
    Content.updateOne({_id:id},{$set:{title,description,content,time:new Date}}).then((result)=>{
        // console.log(result)
        res.render('admin/success', {
            userInfo: req.userInfo,
            optionMessage: {
                location: '内容首页',
                option: '内容修改',
                message: '已成功修改该内容',
                href:'返回内容首页',
            },
            url:'/admin/content',
        });
    })

}