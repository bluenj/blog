
const Content = require('../../schema/content');
const Ctegory = require('../../schema/category');

//展示页面
exports.showAdd = function (req,res) {
    //从数据库中获取所有分类的信息
    Ctegory.find().then((results)=>{
        res.render('admin/content/add',{
            userInfo:req.userInfo,
            results,
        })
    })
};
//接收前台返回的数据
exports.add= function (req,res) {
    //console.log(req.body)
    let {category,title,description,content} = req.body;
    //验证内容标题
    if (title === ''){
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage:{
                location:'内容首页',
                option:'内容添加',
                message:'文章标题不能为空',
            }
        });
        return;
    }
    //验证简介
    if (description === ''){
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage:{
                location:'内容首页',
                option:'内容添加',
                message:'文章简介不能为空',
            }
        });
        return;
    }
    //验证文章主体
    if (content === ''){
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage:{
                location:'内容首页',
                option:'内容添加',
                message:'文章主体不能为空',
            }
        });
        return;
    }
    //从数据库中查找有没有重复标题的
    //如果已经存在该标题则不能添加
    //如果不存在该标题则添加成功
    Content.findOne({
        title,
    }).then((results)=>{
        // console.log(results)
        //这里的results是一个对象
        if (results) {     //已存在
            res.render('admin/error',{
                userInfo:req.userInfo,
                optionMessage:{
                    location:'内容首页',
                    option:'内容添加',
                    message:'该标题已经存在，不能重复添加',
                }
            });
            return;
        }
        //保存数据并渲染成功页面
        new Content({
            title,
            description,
            content,
            category,
            author:req.userInfo.id
        }).save().then((results)=>{
            console.log(results);
            res.render('admin/success',{
                userInfo:req.userInfo,
                optionMessage:{
                    location:'内容首页',
                    option:'内容添加',
                    message:'内容已经成功添加',
                    href:'返回内容首页'
                },
                url:'/admin/content',
            });
        })
    })
}
