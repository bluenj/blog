//引入category分类列表的信息
const Category = require('../../schema/category');
//渲染修改页面
exports.showUpdate = function (req,res) {
    //当前分类名字
    let cate = req.query.category;
    // console.log(category);
    res.render('admin/category/update',{
        userInfo:req.userInfo,
        category:cate,
    })
};

exports.update = function (req,res) {
    //更改后分类的名字
    let category = req.body.category;
    //当前分类名字
    let cate = req.query.category;
    // console.log('category')
    if (category === '') {
        res.render('admin/error', {
            userInfo: req.userInfo,
            optionMessage: {
                location: '分类首页',
                option: '分类修改',
                message: '修改名称不能为空',
            }
        });
        return;
    }
    //从数据库中查询是否存在修改的分类
    //如果存在则不能修改
    //如果不存在则修改成功
    // console.log(cate,category);
    Category.updateOne({name: cate}, {$set: {name: category}}).then((result)=>{
        //console.log(result);
        if (!result.nModified) {//说明原数据库中已存在
            res.render('admin/error', {
                userInfo: req.userInfo,
                optionMessage: {
                    location: '分类首页',
                    option: '分类修改',
                    message: '修改名称已经存在',
                }
            });
            return;
        }
        res.render('admin/success', {
            userInfo: req.userInfo,
            optionMessage: {
                location: '分类首页',
                option: '分类修改',
                message: '已成功修改该分类',
                href:'返回分类首页',
            },
            url:'/admin/category',
        });

    })


}