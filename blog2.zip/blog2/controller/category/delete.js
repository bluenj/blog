//引入category分类列表的信息
const Category = require('../../schema/category');


//渲染删除页面
exports.showDelete = function (req,res) {
    //当前分类名字
    let cate = req.query.category;
    // console.log(category);
    res.render('admin/category/delete',{
        userInfo:req.userInfo,
        category:cate,
    })
};

//从数据库中查找是否存在该分类，如果存在直接删除
exports.delete = function (req,res) {
    let category = req.body.category;
    if (category === '') {      //提交数据不能为空
        res.render('admin/error', {
            userInfo: req.userInfo,
            optionMessage: {
                location: '分类首页',
                option: '分类删除',
                message: '删除名称不能为空',
            }
        });
        return;
    }
    //查找是否存在，如果存在则直接删除
    Category.deleteOne({
        name: category,
    }).then((results) => {
        console.log(results);
            if (!results.deletedCount) {//不存在该分类
                res.render('admin/error', {
                    userInfo: req.userInfo,
                    optionMessage: {
                        location: '分类首页',
                        option: '分类删除',
                        message: '对不起，不存在该分类',
                    }
                });
                return;
            }
            res.render('admin/success', {
                userInfo: req.userInfo,
                optionMessage: {
                    location: '分类首页',
                    option: '分类删除',
                    message: '亲，已经成功删除',
                    href:'返回分类首页',
                },
                url:'/admin/category',
            });

    })
};



