//引入category分类列表的信息
const Category = require('../../schema/category');


exports.showAdd = function (req,res) {
    res.render('admin/category/add',{
        userInfo:req.userInfo,
    })
};

exports.add = function (req,res) {
    //获取提交的分类
    let category = req.body.category;//因为页面上有name属性，所以直接能获取到
    // console.log('category')
    if (category === ''){
        res.render('admin/error',{
            userInfo:req.userInfo,
            optionMessage:{
                location:'分类列表',
                option:'分类添加',
                message:'分类名称不能为空',
            }
        })
    }
    //从数据库中查询是否存在该分类

    Category.findOne({
        name:category,
    }).then((result)=>{
        if (result) {//如果找到此分类，渲染错误页面
            res.render('admin/error',{
                userInfo:req.userInfo,
                optionMessage:{
                    location:'分类列表',
                    option:'分类添加',
                    message:'该分类已存在，不能重复添加',
                }
            });
            return
        }

        new Category({      //保存该分类
            name: category,
        }).save().then(()=>{
            res.render('admin/success',{
                userInfo:req.userInfo,
                optionMessage:{
                    location:'分类列表',
                    option:'分类添加',
                    message:'已成功添加该分类',
                    href:'返回分类首页'
                },
                url:'/admin/category',
            });
        })
    })
};