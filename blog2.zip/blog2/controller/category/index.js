//引入数据库中分类的信息
const category = require('../../schema/category');


exports.showIndex = function (req,res) {
    //从数据库中获取所有分类信息
    let page = +req.query.page||1;   //当前页数
    let limit = 3;  //每页显示的数据量

    category.count().then((count)=>{
        //计算最大页数
        let pageMax = Math.ceil(count/limit);
        page = Math.min(pageMax,page);
        let skip = (page-1)*limit;
        //在数据库中查找数据并渲染
        category.find().limit(limit).skip(skip).sort({_id:-1}).then((results)=>{
            // console.log(results);
            res.render('admin/category/index',{
                userInfo:req.userInfo,
                results,
                page,
                pageMax,
            })
        })
    })
}